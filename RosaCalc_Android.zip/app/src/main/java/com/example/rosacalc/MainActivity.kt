package com.example.rosacalc

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.media.AudioManager
import android.view.*
import android.widget.*
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var display: TextView
    private var expr = ""
    private var sound = true
    private val pink = Color.rgb(233,30,99)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18,24,18,18); setBackgroundColor(Color.WHITE)
        }
        val title = TextView(this).apply { text="🌸 RosaCalc"; textSize=24f; setTextColor(pink); gravity=Gravity.CENTER; setPadding(0,0,0,12) }
        main.addView(title, LinearLayout.LayoutParams(-1,60))
        display = TextView(this).apply {
            text="0"; textSize=38f; gravity=Gravity.CENTER_VERTICAL or Gravity.END
            setTextColor(Color.DKGRAY); setPadding(18,0,18,0)
        }
        main.addView(display, LinearLayout.LayoutParams(-1,0,1.1f))
        val grid = GridLayout(this).apply { columnCount=4; rowCount=5; useDefaultMargins=true }
        val keys = arrayOf("AC","⌫","÷","×","7","8","9","−","4","5","6","+","1","2","3","=","0",".","%","🔊")
        for (k in keys) {
            val v=Button(this).apply {
                text=k; textSize=22f; setTextColor(if(k in arrayOf("+","−","×","÷","=")) pink else Color.DKGRAY)
                setBackgroundResource(com.example.rosacalc.R.drawable.button)
                setOnClickListener { press(k) }
            }
            val p=GridLayout.LayoutParams().apply { width=0; height=0; columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); rowSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); setMargins(5,5,5,5) }
            grid.addView(v,p)
        }
        main.addView(grid, LinearLayout.LayoutParams(-1,0,2.5f))
        setContentView(main)
    }

    private fun press(k:String) {
        if(sound) (getSystemService(AUDIO_SERVICE) as AudioManager).playSoundEffect(AudioManager.FX_KEY_CLICK)
        when(k) {
            "AC" -> expr=""
            "⌫" -> if(expr.isNotEmpty()) expr=expr.dropLast(1)
            "🔊" -> { sound=!sound; Toast.makeText(this, if(sound) "Sonido activado" else "Sonido desactivado", Toast.LENGTH_SHORT).show() }
            "=" -> expr = try { format(eval(expr)) } catch(e:Exception) { "Error" }
            else -> { if(expr=="Error") expr=""; expr += when(k){"×"->"*";"÷"->"/";"−"->"-";else->k} }
        }
        display.text=if(expr.isEmpty()) "0" else expr
    }

    private fun format(x:Double):String = if(x.isFinite() && x==x.toLong().toDouble()) x.toLong().toString() else "%.8f".format(x).trimEnd('0').trimEnd('.')

    private fun eval(s:String):Double {
        if(s.isBlank()) return 0.0
        val t=s.replace("%","/100")
        return Parser(t).parse()
    }

    private class Parser(private val s:String) {
        var p=0
        fun parse():Double { val v=add(); if(p<s.length) throw Exception(); return v }
        fun add():Double { var v=mul(); while(p<s.length){ when(s[p]){'+'->{p++;v+=mul()};'-'->{p++;v-=mul()};else->return v} }; return v }
        fun mul():Double { var v=num(); while(p<s.length){ when(s[p]){'*'->{p++;v*=num()};'/'->{p++;v/=num()};else->return v} }; return v }
        fun num():Double { val st=p; if(p<s.length && (s[p]=='+'||s[p]=='-')) p++; while(p<s.length && (s[p].isDigit()||s[p]=='.')) p++; if(st==p) throw Exception(); return s.substring(st,p).toDouble() }
    }
}
